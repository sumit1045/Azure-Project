const schema = `
  type Query {
    add(x: Int, y: Int): Int
  }
`

export default schema
